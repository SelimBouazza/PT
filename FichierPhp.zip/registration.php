<?php
    
  include("connexion.php");
 
$login = $_POST['login']; 
$password = $_POST['mdp'];
$firstName=$_POST['first_name'];
$surname=$_POST['surname'];
$email=$_POST['email'];

echo($login);
echo($password);
echo($firstName);
echo($surname);
echo($email);


$req="INSERT INTO personne VALUES(LAST_INSERT_ID(),'".$firstName."','".$surname."','".$email."','".$password."','".$login."')";

$sql=$bdd->prepare($req);
        $sql->execute();
        echo "\nPDO::errorInfo():\n";
   print_r($sql->errorInfo());
        
        

?>