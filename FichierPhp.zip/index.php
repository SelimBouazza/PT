<?php
    
    //connexion a la BdD via PDO
    $serv="mysql:host=localhost;dbname=id4799679_searcheat";
    $user="id4799679_01";
    $mdp="13005767";
 
$bdd = new PDO($serv,$user,$mdp);
$req="SELECT * FROM restaurant";
$sql=$bdd->prepare($req);
        $sql->execute();
        $reponse=$sql->fetchAll();
        echo json_encode($reponse);

?>

