<?php
    
include("connexion.php");
$req="SELECT * FROM restaurateur";
$sql=$bdd->prepare($req);
        $sql->execute();
        $reponse=$sql->fetchAll();
        echo json_encode($reponse);

?>
