<?php
    
include("connexion.php");
 
$login = $_POST['login']; 
$password = $_POST['mdp'];


$req="SELECT * FROM personne WHERE login ='".$login."' AND mdp ='".$password."'";
$sql=$bdd->prepare($req);
        $sql->execute();
        $reponse=$sql->fetchAll();
        echo json_encode($reponse);

?>