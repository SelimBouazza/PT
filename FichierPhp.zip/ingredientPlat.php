<?php
    
include("connexion.php");
$req="SELECT * FROM ingredient_plat";
$sql=$bdd->prepare($req);
        $sql->execute();
        $reponse=$sql->fetchAll();
        echo json_encode($reponse);

?>