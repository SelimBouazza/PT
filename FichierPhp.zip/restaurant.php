<?php
    
include("connexion.php");
$req="SELECT * FROM restaurant";
$sql=$bdd->prepare($req);
        $sql->execute();
        $reponse=$sql->fetchAll();
        echo json_encode($reponse);

?>
